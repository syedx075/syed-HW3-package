library(testthat)
library(syedTools)

test_check("syedTools")
