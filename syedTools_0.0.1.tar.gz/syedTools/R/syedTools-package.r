#' syedTools.
#'
#' @name syedTools
#' @docType package
NULL
